# StoryGen - Consistent Character Tool

Aplikasi desktop sederhana untuk membuat cerita dengan karakter konsisten.
- Input: judul/ide cerita
- Output: otomatis generate prompt + gambar dari API Veo 3

## 🚀 Cara Jalankan
1. Clone repo ini:
   ```bash
   git clone https://github.com/USERNAME/storygen-tool.git
   cd storygen-tool
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Jalankan aplikasi:
   ```bash
   python main.py
   ```

4. Masukkan judul cerita → klik **Start Processing** → klik **Generate & Download** → hasil gambar tersimpan di folder `outputs/`.

## ⚡ Catatan
- Pastikan sudah punya **API Key Veo 3**
- Endpoint: `https://api.veo.com/v1/images`
- Model default: `veo-3`
